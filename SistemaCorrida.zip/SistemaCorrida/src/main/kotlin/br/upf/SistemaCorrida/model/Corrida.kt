package br.upf.SistemaCorrida.model

import java.time.LocalDate
import java.time.LocalDateTime

class Corrida(inscritos: List<Any>, status: StatusCorrida, descricao: String, dataFim: LocalDateTime, dataInicio: LocalDateTime, data: LocalDate, circuito: String, id: Int) {



    data class Corrida(
            val id: Long? = null,
            val circuito: String,
            val data: LocalDate,
            val dataInicio: LocalDateTime,
            val dataFim: LocalDateTime,
            val descricao: String,
            val status: StatusCorrida,
            val inscritos: List<Inscricao> = listOf()
    )
}