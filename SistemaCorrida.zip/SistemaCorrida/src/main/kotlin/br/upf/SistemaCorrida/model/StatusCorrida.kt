package br.upf.SistemaCorrida.model

enum class StatusCorrida {
    PREVISTO,
    ABERTO,
    ENCERRADO,
    CANCELADO
}