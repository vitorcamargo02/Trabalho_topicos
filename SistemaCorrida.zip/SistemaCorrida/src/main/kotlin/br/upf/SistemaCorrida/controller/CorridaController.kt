package br.upf.SistemaCorrida.controller

import br.upf.SistemaCorrida.converters.CorridaConverter
import br.upf.SistemaCorrida.dtos.CorridaDTO
import br.upf.SistemaCorrida.dtos.CorridaResponseDTO
import br.upf.SistemaCorrida.model.Corrida
import br.upf.SistemaCorrida.repository.CorridaRepository
import br.upf.SistemaCorrida.service.CorridaService
import org.springframework.stereotype.Service
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/corridas")
class CorridaController(val service: CorridaService<Any?>) {

    @GetMapping
    fun listar(): List<Corrida> {
        return service.listar()
    }
    @PostMapping
    fun cadastrar (@RequestBody dto: CorridaDTO){
        service.cadastrar(dto)
    }
    @Service
    class CorridaService(private var repository: CorridaRepository,
            private val converter: CorridaConverter) {

        fun listar(): List<Corrida> {
            return repository.findAll()
        }

        fun buscarPorId(id: Long): Corrida {
            return repository.findAll().first { it.id == id }
        }

        fun cadastrar(corrida: CorridaDTO) {
            repository.cadastrar(converter.toCorrida(corrida))
        }

    }
    }
    @GetMapping
    fun listar(): List<CorridaResponseDTO>{
        return service.listar()
    }
    @GetMapping("/{id}")
    fun buscarPorId(@PathVariable id: Long): CorridaResponseDTO{
        return service.buscarPorId(id)
    }

}
