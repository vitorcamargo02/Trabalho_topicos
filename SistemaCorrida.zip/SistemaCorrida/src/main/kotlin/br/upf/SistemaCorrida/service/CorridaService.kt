package br.upf.SistemaCorrida.service

import br.upf.SistemaCorrida.dtos.CorridaResponseDTO
import br.upf.SistemaCorrida.model.Corrida
import br.upf.SistemaCorrida.repository.CorridaRepository
import org.springframework.stereotype.Service


@Service
class CorridaService<CorridaDTO>(private val repository: CorridaRepository) {
    fun listar(): List<Corrida> {
        return repository.findAll()
    }

    fun cadastrar(dto: CorridaDTO) {

    }

    fun listar(): List<CorridaResponseDTO>{
        return repository.findAll()
                .map(converter::toCorridaResponseDTO)
    }

    fun buscarPorId (id: Long): CorridaResponseDTO{
        val corrida = repository.findAll().first {it.id == id}
        return converter.toCorridaResponseDTO (corrida)
    }
}
