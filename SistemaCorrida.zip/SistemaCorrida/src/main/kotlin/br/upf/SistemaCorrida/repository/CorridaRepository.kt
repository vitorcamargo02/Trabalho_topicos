package br.upf.SistemaCorrida.repository

import br.upf.SistemaCorrida.model.Corrida
import br.upf.SistemaCorrida.model.StatusCorrida
import org.springframework.stereotype.Repository
import java.time.LocalDate

@Repository
class CorridaRepository(private var corridas: MutableList<Corrida>) {
    private var idCont = 4L

    init {
        val hoje = LocalDate.now()
        val corrida1 = Corrida(
                id = 1,
                circuito = "Autódromo Internacional de Guaporé",
                data = hoje,
                dataInicio = hoje.atStartOfDay().plusDays(10),
                dataFim = hoje.atStartOfDay().plusDays(20),
                descricao = "Leve seu motor ao melhor potencial",
                status = StatusCorrida.PREVISTO,
                inscritos = listOf()
        )
        val corrida2 = Corrida(
                id = 2,
                circuito = "VeloPark",
                data = hoje.plusDays(7),
                dataInicio = hoje.atStartOfDay().plusDays(17),
                dataFim = hoje.atStartOfDay().plusDays(27),
                descricao = "O melhor das corridas automobilisticas",
                status = StatusCorrida.ABERTO,
                inscritos = listOf()
        )
        val corrida3 = Corrida(
                id = 3,
                circuito = "Autódromo de Santa Cruz do Sul",
                data = hoje.plusDays(14),
                dataInicio = hoje.atStartOfDay().plusDays(24),
                dataFim = hoje.atStartOfDay().plusDays(34),
                descricao = "Os melhores veículos do Estado",
                status = StatusCorrida.CANCELADO,
                inscritos = listOf()
        )
        corridas = mutableListOf(corrida1, corrida2, corrida3)
    }

    fun findAll() = corridas

    fun cadastrar(corrida: Corrida){
        corridas.add(corrida.copy(id = idCont++))
    }

}
