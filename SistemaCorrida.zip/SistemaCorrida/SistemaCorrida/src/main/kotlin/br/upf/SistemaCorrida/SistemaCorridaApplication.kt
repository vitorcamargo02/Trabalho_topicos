package br.upf.SistemaCorrida

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class SistemaCorridaApplication

fun main(args: Array<String>) {
	runApplication<SistemaCorridaApplication>(*args)
}
