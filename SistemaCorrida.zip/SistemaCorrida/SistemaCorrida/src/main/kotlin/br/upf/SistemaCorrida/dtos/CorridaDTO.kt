package br.upf.SistemaCorrida.dtos

import br.upf.SistemaCorrida.model.StatusCorrida
import java.time.LocalDate
import java.time.LocalDateTime

data class CorridaDTO(
        val circuito: String,
        val data: LocalDate,
        val dataInicio: LocalDateTime,
        val dataFim: LocalDateTime,
        val descricao: String,
        val status: StatusCorrida
)