package br.upf.SistemaCorrida.service

import br.upf.SistemaCorrida.model.Corrida
import br.upf.SistemaCorrida.repository.CorridaRepository
import org.springframework.stereotype.Service

@Service
class CorridaService(private val repository: CorridaRepository) {
    fun listar(): List<Corrida> {
        return repository.findAll()
    }
}
