package br.upf.SistemaCorrida.converters

import br.upf.SistemaCorrida.dtos.CorridaDTO
import br.upf.SistemaCorrida.dtos.CorridaResponseDTO
import br.upf.SistemaCorrida.model.Corrida
import org.springframework.stereotype.Component

@Component
class CorridaConverter {
    fun toCorrida(dto: CorridaDTO): Corrida {
        return Corrida(
                circuito = dto.circuito,
                data = dto.data,
                dataInicio = dto.dataInicio,
                dataFim = dto.dataFim,
                descricao = dto.descricao,
                status = dto.status,
                inscritos = listOf()
        )
    }

}