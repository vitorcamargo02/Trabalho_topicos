package br.upf.SistemaCorrida.model

import java.time.LocalDate
import java.time.LocalDateTime

data class Corrida(
    val id: Long? = null,
    val circuito: String,
    val data: LocalDate,
    val dataInicio: LocalDateTime,
    val dataFim: LocalDateTime,
    val descricao: String,
    val status: String,
    val inscritos: List<Inscricao> = listOf()
)
