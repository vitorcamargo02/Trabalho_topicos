package br.upf.SistemaCorrida.controller

import br.upf.SistemaCorrida.model.Corrida
import br.upf.SistemaCorrida.service.CorridaService
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/corridas")
class CorridaController(val service: CorridaService) {

    @GetMapping
    fun listar(): List<Corrida> {
        return service.listar()
    }
}
